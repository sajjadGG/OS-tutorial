
#include<stdio.h>
#include<sys/socket.h>
#include<unistd.h>
#include<stdlib.h>
#include<netinet/in.h>
#include<string.h>
#include<pthread.h>

#define TILL_SEQ 10000
#define N_THREADS 10


double res;
const int bucket = TILL_SEQ/N_THREADS;

// (-1)**n/(2*n+1) n=0 to inf

double estimate_pi(int from , int till){
	int i=0;
	printf("got %d %d\n",from,till);
	double res_local;
	for(i=from;i<till;i++){
		res_local += i%2==0 ? 1.0/(2.0*i+1.0) : -1.0/(2.0*i+1.0); 
	}
	return res_local;

}

void *runner(void *param){
	int from = *(int *)(param);
	int till = from+bucket;
	double rl = estimate_pi(from,till);
	res+=rl;
	pthread_exit(0);
}

int main(int argc, char const *argv[]){
	pthread_t workers[N_THREADS];
        int *froms = malloc(N_THREADS*sizeof(int));	
	pthread_attr_t attr;
	int i=0;
	for(i=0;i<N_THREADS;i++){

		froms[i] = i*bucket;
		//create thread
		pthread_create(&workers[i],NULL,runner,(void *)&froms[i]);
		//wait for thread to exit
	}
	for(i=0;i<N_THREADS;i++)
		pthread_join(workers[i],NULL);
	
	printf("res is %f\n",res);
}
