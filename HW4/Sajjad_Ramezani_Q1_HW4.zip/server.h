


int isFileWritable(const char* path);
int isFileExecutable(const char* path);

void getLine(char* line);
void assignSeparated(char* line,const char* delim,...);
void removeWord(char* line,const char* delim, char* res, int num);

