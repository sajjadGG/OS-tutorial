
#include<stdio.h>
#include<sys/socket.h>
#include<unistd.h>
#include<stdlib.h>
#include<netinet/in.h>
#include<string.h>
#include<pthread.h>
#include "server.h"
//s
#define M 10000
#define MAX_TASKS 100
#define UNITCOUNT 5
#define TASKMAX 10
#define N_THREADS 5
QUEUE_TEMPLATE(Task);
Queue_Task* mq;
typedef struct funcarg{
	int (*func)(int);
	Task* t;

} FuncArg;

QUEUE_TEMPLATE(FuncArg);

Queue_FuncArg* qs[UNITCOUNT];

int unit_0(int value){
	return (value+7)%M;
}

int unit_1(int value){
	return (2*value)%M;
}

int unit_2(int value){
	(value*value*value*value*value)%M;
}

int unit_3(int value){
	value - 19;
}

int unit_4(int value){
	printf("%d\n",value);
}

void addMainqueue(Task * t){
	Enqueue_Task(mq,*t);
}

void *runner(void *param){
		int qi = atoi(param);
		printf("in runner %d size %d\n",qi , qs[qi]->size);
		while(qs[qi]->size<=0); //busy waiting
		FuncArg fa = front_FuncArg(qs[qi]); 
		Dequeue_FuncArg(qs[qi]);
		fa.t->value = fa.func(fa.t->value);
		fa.t->processed_till++;
		//TODO:add lock ?
		addMainqueue(fa.t);
		pthread_exit(0);
}

//TODO: read from upto
int reception(char* filename,Task* tasks[]){
	FILE * fp;
	char * line = NULL;
	size_t len =0;
	ssize_t read;

	line=(char *)malloc(STRING_MAX_LEN);

	fp = fopen(filename,"r");
	if(fp==NULL)
		exit(EXIT_FAILURE);
	int i=0;
	while((read = getline(&line,&len,fp)) != -1){
		printf("%s\n",line);
		tasks[i] =(Task *) malloc(sizeof(Task));
		char * rem = (char * )malloc(sizeof(char)*1000);
		assignSeparated(line," ",3, rem,&(tasks[i]->id),&(tasks[i]->value),&(tasks[i]->unit_count));
		tasks[i]->processed_till=0;
		tasks[i]->unit_id = (int *)malloc(sizeof(int)*tasks[i]->unit_count);
		printf("before line is %s\n",rem);
		castArrayInt(rem," ",tasks[i]->unit_id);
		printf("task id is %d , uc: %d \n",tasks[i]->id, tasks[i]->unit_count);
		int k=0;
		int ti = tasks[i]->unit_count;
		for(k=0;k<ti;k++){
			printf("at %d is %d ",k,tasks[i]->unit_id[k]);
		}
		printf("\n");
		i++;
	}
	return i;
}
void dispatch(Task* task){
	int u = task->unit_id[task->processed_till];
	FuncArg * fa = malloc(sizeof(FuncArg));
	fa->t = task;
	printf("got task: %d processed at : %d  u:%d\n",task->id,task->processed_till,u);
	if(u==0)
		fa->func = unit_0;
	if(u==1)
		fa->func = unit_1;
	if(u==2)
		fa->func = unit_2;
	if(u==3)
		fa->func = unit_3;
	if(u==4)
		fa->func = unit_4;

	Enqueue_FuncArg(qs[u],*fa);
	printf("size of %d is %d\n",u,qs[u]->size);	
}
int main(int argc, char const *argv[]){
	mq = createQueue_Task(TASKMAX);
	int i=0;
	pthread_t workers[N_THREADS];
	for(i=0;i<UNITCOUNT;i++){
		qs[i] = createQueue_FuncArg(TASKMAX);
		pthread_attr_t attr;
		pthread_attr_init(&attr);
		pthread_attr_setdetachstate(&attr,PTHREAD_CREATE_DETACHED);
		pthread_create(&workers[i],&attr,runner,&i);
	}
	
	Task * tasks[MAX_TASKS];
	int tail = reception("test.txt",tasks);
	for(i=0;i<tail;i++)
		Enqueue_Task(mq,*tasks[i]);

	printf("main queue size %d\n",mq->size);
	while(1){
	while(mq->size>0){
		printf("here mq :%d\n",mq->size);
		Task t = front_Task(mq);
		Dequeue_Task(mq);
		dispatch(&t);
	}
	}
}
