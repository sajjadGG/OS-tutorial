
#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<ctype.h>
#include<stdarg.h>
#include<string.h>

#define INPUT_BUFFER_MAX 256




// File
int isFileWritable(const char* path){
	return access(path, F_OK | W_OK);

}


int isFileExecutable(const char* path){
	return access(path,F_OK | X_OK);
}


// Reading Input

char* rtrim(char *s){

	char *back = s + strlen(s);
	while(isspace(*--back));
		*(back+1)='\0';
	return s;
}
void getLine(char* line, int max){
	
	if(fgets(line,INPUT_BUFFER_MAX,stdin)==NULL){
		
	}
	rtrim(line);
}
//TODO: make it generic and pass a convert function
void assignSeparated(char *line, const char* delim,int np,char * rem, ...){
	char* token_ptr = strtok(line,delim);
	va_list ap;
	int j=0;
	va_start(ap,delim);
	while(token_ptr!=NULL){
		if(j<np){
		int* argCast=va_arg(ap,int *);
		*argCast = atoi(token_ptr);
		
		}
		else{
			strcat(rem,token_ptr);
			strcat(rem," ");
		}

		j++;
		token_ptr = strtok(NULL,delim);
	}
	va_end(ap);
}

void castArrayInt(char *line, const char* delim,int* array){
	
	char* token_ptr = strtok(line,delim);
	int j=0;
	while(token_ptr!=NULL){
		array[j++]=atoi(token_ptr);
		printf("why %d\n",array[j-1]);
		token_ptr = strtok(NULL,delim);
	}

}

void removeWord(char* line,const char* delim, char* res , int num){
	char* token_ptr = strtok(line,delim);
	int j=0;
	while(token_ptr!=NULL){
		if(j!=num)
			strcat(res,token_ptr);
	}

}





